USE webapp;

DROP TABLE IF EXISTS `app`;
CREATE TABLE `app` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app_name` varchar(255) DEFAULT NULL,
  `avatar_path` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `download_path` varchar(255) DEFAULT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `tag_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `app`
--

LOCK TABLES `app` WRITE;
INSERT INTO `app` VALUES (1,'League of Legends','/img/upload/LOL.jpg','Liên Minh Huyền Thoại, thường được gọi ngắn gọn là Liên Minh, là một trò chơi video thể loại đấu trường trận chiến trực tuyến nhiều người chơi được Riot Games công bố lần đầu tiên vào ngày 7/10/2008.','/file/h2-setup-2022-06-13.exe','game','MOBA'),(2,'The Glory','/img/upload/Glory.jpg','Vinh quang trong thù hận là một bộ phim truyền hình trực tuyến của Hàn Quốc do Kim Eun-sook viết kịch bản và Ahn Gil-ho đạo diễn.','/file/2023-03-31 20-31-20.mp4','phim','Kịch tính, Drama'),(3,'Epic Seven','/img/upload/Epic7.jpg','Là một tựa game đến từ Hàn Quốc được phát triển bởi Smile Gate Company','/file/h2-setup-2022-06-13.exe','game','Hành động, Gacha, Nhập vai'),(4,'Avenger End Game','/img/upload/Avengers_Endgame.jpg','Avengers: Hồi kết là phim điện ảnh siêu anh hùng Mỹ ra mắt năm 2019, do Marvel Studios sản xuất và Walt Disney Studios Motion Pictures phân phối.','/file/2023-03-31 20-31-20.mp4','phim','Kịch tính, siêu anh hùng, hành động'),(5,'Đắc nhân tâm','/img/upload/download (2).jfif','Đắc nhân tâm (Được lòng người), tên tiếng Anh là How to Win Friends and Influence People là một quyển sách nhằm tự giúp bản thân (self-help) bán chạy nhất từ trước đến nay. Quyển sách này do Dale Carnegie viết và đã được xuất bản lần đầu vào năm 1936.','/file/Ho So Tam Ly Pham Toi - Cuong Tuyet An.pdf','sach','Self-help'),(6,'Hồ sơ tâm lý tội phạm','/img/upload/Book.jpg','Hồ sơ tâm lý phạm tội là một bộ sách bao gồm gần như toàn bộ nguyên tố phạm tội đáng kinh ngạc: Án bằm thây chưa giải quyết, ác quỷ ngược đãi trẻ em, điện thoại từ địa ngục, mộ huyệt tàn thi, sát nhân ma chú. . .','/file/Ho So Tam Ly Pham Toi - Cuong Tuyet An.pdf','sach','Kịch tính, Drama');
UNLOCK TABLES;

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `avatar_path` varchar(255) DEFAULT NULL,
  `cash_amount` int DEFAULT NULL,
  `created_date` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
INSERT INTO `user` VALUES (1,'/img/user-avatar/default-avatar.jpg',0,'2023-04-28 11:08:06','test@gmail.com','User','Nam','Test','$2a$10$7eVRSC1mZai9Mqhqipuv/eKCTKhEeQFPZ6PZdclhTMa/fQlrwfNfK',NULL),(2,'/img/user-avatar/default-avatar.jpg',0,'2023-04-28 11:08:24','admin@gmail.com','Admin','Nam','Test','$2a$10$tyXmWmKvQMM6Wr6P3tRKAO/41LV6mcMf7/x1TFOGeFRfoPKAXJlVC',NULL);
UNLOCK TABLES;

DROP TABLE IF EXISTS `card`;
CREATE TABLE `card` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `amount` int DEFAULT NULL,
  `card_code` varchar(255) DEFAULT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `card`
--

LOCK TABLES `card` WRITE;
/*!40000 ALTER TABLE `card` DISABLE KEYS */;
/*!40000 ALTER TABLE `card` ENABLE KEYS */;
UNLOCK TABLES;

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
INSERT INTO `role` VALUES (1,'USER'),(2,'ADMIN');
UNLOCK TABLES;

DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app-name` varchar(255) DEFAULT NULL,
  `download_path` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `tag_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
INSERT INTO `cart` VALUES (1,'Epic Seven','/file/h2-setup-2022-06-13.exe','test@gmail.com','game','Hành động, Gacha, Nhập vai');
UNLOCK TABLES;

DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `role_id` bigint DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `FKka3w3atry4amefp94rblb52n7` (`role_id`),
  CONSTRAINT `FKhjx9nk20h4mo745tdqj8t8n9d` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKka3w3atry4amefp94rblb52n7` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
INSERT INTO `user_role` VALUES (1,1),(2,2);
UNLOCK TABLES;